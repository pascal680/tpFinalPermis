package com.tpfinal;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.tpfinal.model.Citoyen;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class CheckValidity extends AppCompatActivity {

    EditText editTextNumAssMal;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_check_validity);

        editTextNumAssMal = findViewById(R.id.editTextNumAssMal);

    }

    public void check(View view){
        checkValidity(editTextNumAssMal.getText().toString());
    }



    private void checkValidity(String numAssMal){
        Retrofit.Builder builder = new Retrofit.Builder()
                .baseUrl("http://10.0.2.2:9393/ministere/")
                .addConverterFactory(GsonConverterFactory.create());

        Retrofit retrofit = builder.build();

        CitoyenClient client = retrofit.create(CitoyenClient.class);
        Call<Boolean> call = client.getAssuranceMaladieValidity(numAssMal);

        call.enqueue(new Callback<Boolean>() {
            @Override
            public void onResponse(Call<Boolean> call, Response<Boolean> response) {
                Log.i("Boolean get", response.body().toString());
                if(response.body()) {
                    Intent intent = new Intent(CheckValidity.this, SignUp.class);
                    intent.putExtra("numAssMal", numAssMal);
                    startActivity(intent);
                }else{
                    Toast.makeText(CheckValidity.this, "Numero d'assurance maladie n'est pas valide", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<Boolean> call, Throwable t) {
                Toast.makeText(CheckValidity.this, "Incapable de verifier la validite", Toast.LENGTH_SHORT).show();
            }
        });
    }
}