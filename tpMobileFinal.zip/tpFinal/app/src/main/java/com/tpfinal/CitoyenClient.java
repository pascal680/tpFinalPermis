package com.tpfinal;

import com.tpfinal.model.Citoyen;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Path;

public interface CitoyenClient {

    @POST("addCitoyen")
    Call<Citoyen> createCitoyen(@Body  Citoyen citoyen);

    @GET("{numAssMal}")
    Call<Boolean> getAssuranceMaladieValidity(@Path("numAssMal") String numAssMal);
}
