package com.tpfinal.model;


import java.io.Serializable;
import java.util.Set;

public class Citoyen implements Serializable {

    private int id;

    private String nom;

    private String prenom;

    private String password;

    private String email;

    private String numAssMal;

    private char sexe;

    private int age;

    private String numTelephone;

    private String villeResidence;

    private Permis permis;

    private Set<Citoyen> enfants;


    public Citoyen() {
    }

    public Citoyen(int id, String nom, String prenom, String password, String email, String numAssMal, char sexe, int age, String numTelephone, String villeResidence, Permis permis, Set<Citoyen> enfants) {
        this.id = id;
        this.nom = nom;
        this.prenom = prenom;
        this.password = password;
        this.email = email;
        this.numAssMal = numAssMal;
        this.sexe = sexe;
        this.age = age;
        this.numTelephone = numTelephone;
        this.villeResidence = villeResidence;
        this.permis = permis;
        this.enfants = enfants;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getPrenom() {
        return prenom;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getNumAssMal() {
        return numAssMal;
    }

    public void setNumAssMal(String numAssMal) {
        this.numAssMal = numAssMal;
    }

    public char getSexe() {
        return sexe;
    }

    public void setSexe(char sexe) {
        this.sexe = sexe;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getNumTelephone() {
        return numTelephone;
    }

    public void setNumTelephone(String numTelephone) {
        this.numTelephone = numTelephone;
    }

    public String getVilleResidence() {
        return villeResidence;
    }

    public void setVilleResidence(String villeResidence) {
        this.villeResidence = villeResidence;
    }

    public Permis getPermis() {
        return permis;
    }

    public void setPermis(Permis permis) {
        this.permis = permis;
    }

    public Set<Citoyen> getEnfants() {
        return enfants;
    }

    public void setEnfants(Set<Citoyen> enfants) {
        this.enfants = enfants;
    }

}
