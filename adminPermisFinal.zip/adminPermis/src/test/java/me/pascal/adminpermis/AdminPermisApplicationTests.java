package me.pascal.adminpermis;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AdminPermisApplicationTests {

    @Test
    void contextLoads() {
    }

}
