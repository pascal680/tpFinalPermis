package me.pascal.adminpermis.controller;

import me.pascal.adminpermis.model.Citoyen;
import me.pascal.adminpermis.model.Permis;
import me.pascal.adminpermis.repository.CitoyenRepository;
import me.pascal.adminpermis.repository.PermisRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller; //MVC
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class AdminController {

    @Autowired
    CitoyenRepository citoyenRepository;
    @Autowired
    PermisRepository permisRepository;

    @RequestMapping(path = "/")
    public String index(){
        return "index";
    }

    @GetMapping(path = "/citoyens")
    public String getAllCitoyens(Model model){
        model.addAttribute("listCitoyens", citoyenRepository.findAll());
        return "citoyens";
    }


    @GetMapping(path = "/permis")
    public String getAllPermis(Model model){
        model.addAttribute("listPermis", permisRepository.findAll());
        return "permis";
    }

    @GetMapping("/citoyens/edit/{id}")
    public String editCitoyen(Model model, @PathVariable(value = "id") int id){
        Citoyen citoyen = citoyenRepository.findById(id);
        model.addAttribute("citoyen", citoyen);
        model.addAttribute("permis", citoyen.getPermis());
        return "citoyenEdit";
    }

    @PostMapping("/citoyenUpdate")
    public String updateCitoyen(@ModelAttribute Citoyen citoyen){
        Permis permisUntouched = citoyenRepository.findById(citoyen.getId()).getPermis();
        citoyen.setPermis(permisUntouched); //Permet de ne pas perdre le permis car il n'est pas linker dans notre form
        citoyenRepository.save(citoyen);
        return "redirect:/citoyens";
    }

    @GetMapping("/citoyen/delete/{id}")
    public String deleteCitoyen(@PathVariable(value = "id") int id) {
        citoyenRepository.deleteById(id);
        return "redirect:/citoyens";
    }

    @GetMapping("/permis/delete/{id}")
    public String deletePermis(@PathVariable(value = "id") int id) {
        permisRepository.deleteById(id);
        return "redirect:/permis";
    }


}
