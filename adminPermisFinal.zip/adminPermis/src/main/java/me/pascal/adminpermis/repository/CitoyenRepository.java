package me.pascal.adminpermis.repository;
import me.pascal.adminpermis.model.Citoyen;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CitoyenRepository extends JpaRepository<Citoyen, Integer> {

    public Citoyen findCitoyenByEmailIgnoreCase(String email);

    public Citoyen findCitoyenByEmailIgnoreCaseAndPassword(String email, String pwd);

    public Citoyen save(Citoyen citoyen);

    public Citoyen findById(int id);

    public void deleteById(int id);

    public void deleteByEmail(String email);




}
