package me.pascal.adminpermis;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AdminPermisApplication {

    public static void main(String[] args) {
        SpringApplication.run(AdminPermisApplication.class, args);
    }

}
