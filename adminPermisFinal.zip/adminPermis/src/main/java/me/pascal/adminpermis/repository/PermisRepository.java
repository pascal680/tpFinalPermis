package me.pascal.adminpermis.repository;

import me.pascal.adminpermis.model.Permis;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface PermisRepository extends JpaRepository<Permis, Integer> {

    public List<Permis> findByDateExpirationPermis(LocalDate date);

    public List<Permis> findByDateExpirationPermisBefore(LocalDate date);

    public List<Permis> findByTypePermisIgnoreCase(String typePermis);

    public void deleteByIdPermis(int idPermis);

    public Permis getOne(Integer idPermis);


}
