package me.pascal.tpPermis.controller;

import me.pascal.tpPermis.model.Citoyen;
import me.pascal.tpPermis.model.Permis;
import me.pascal.tpPermis.service.AppService;
import org.apache.tomcat.util.http.fileupload.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;

@RestController
@CrossOrigin (origins = {"http://localhost:4220", "http://localhost:9292"})

public class PermisSanteController {
    @Autowired
    AppService service;

    @RequestMapping(value = "/permisSante/login/{email}/{password}", method = RequestMethod.GET)
    public Citoyen login(@PathVariable String email, @PathVariable String password){
        return service.login(email, password);
    }

    @RequestMapping(value = "/permisSante/{email}", method = RequestMethod.GET)
    public boolean loginExist(@PathVariable String email){
        return service.isLoginExist(email);
    }


    @RequestMapping(value = "/permisSante/addCitoyen/{numAssMalParent}", method = RequestMethod.POST)
    public boolean subscribe(@RequestBody Citoyen citoyen, @PathVariable String numAssMalParent){
        return service.addEnfant(numAssMalParent, citoyen);
    }

    @PostMapping(path = "/permisSante/addCitoyen")
    public Citoyen addCitoyen(@RequestBody Citoyen citoyen){
        return service.addCitoyen(citoyen);
    }

    @PostMapping(path = "/permisSante/requestPermis")
    public boolean requestPermis(@RequestBody Citoyen citoyen){
        return service.requestPermis(citoyen);
    }

    @PostMapping(path = "/permisSante/sendEmail")
    public boolean sendEmail(@RequestBody Citoyen citoyen){
        return service.generateAll(citoyen);
    }

    @PostMapping(path = "/permisSante/addEnfant/{numAssMalParent}")
    public boolean addEnfant(@PathVariable String numAssMalParent, @RequestBody Citoyen enfant){
        return service.addEnfant(numAssMalParent, enfant);
    }

    @GetMapping("/permisSante/qrcode/{numAssMal}")
    public void getPermisQrCode(@PathVariable String numAssMal, HttpServletResponse response) {
        try {
            response.setContentType("image/jpeg");

            Citoyen citoyen = service.findCitoyenByNumAssMal(numAssMal);

            InputStream inputStream = new ByteArrayInputStream(service.getFullQrCitoyenByteArray(citoyen));
            IOUtils.copy(inputStream, response.getOutputStream());
        }catch (Exception e){
            System.out.println("No permis for this account");
        }
    }

}
