package me.pascal.tpPermis.service;

import org.springframework.stereotype.Repository;

public interface ServiceData {

    int QR_CODE_WIDTH = 200;
    int QR_CODE_HEIGHT = 300;

    String QR_EXTENSION = ".PNG";
    String PDF_EXTENSION = ".pdf";

    String FILE_PATH_BASE = "B:/SCHOOL/AL/Sem_8/prog_transactionnel/TP/tpPermis/genatedData/";

}
