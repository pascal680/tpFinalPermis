package me.pascal.tpPermis;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TppermisApplicationTests {

    @Test
    void contextLoads() {
    }

}
