package com.ministereWs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MinistereWsApplication {

    public static void main(String[] args) {
        SpringApplication.run(MinistereWsApplication.class, args);
    }

}
