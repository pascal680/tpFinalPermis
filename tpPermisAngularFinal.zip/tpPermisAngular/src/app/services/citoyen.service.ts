import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { CitoyenSante } from '../models/citoyenSante';
import { GenericService } from './genericService';

@Injectable({
  providedIn: 'root'
})
export class CitoyenService extends GenericService<CitoyenSante, Number>{

  constructor(http: HttpClient) {
    super(http, "http://localhost:9393/ministere")
   }
}
