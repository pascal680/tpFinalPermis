  
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';


export class GenericService<T, ID> {

    constructor(protected http: HttpClient, protected url: string){}
   
   
    save(t: T): Observable<T> {
        return this.http.post<T>(this.url + '/addCitoyen', t);
    }

    saveEnfant(numAssMalParent: string, t: T): Observable<boolean> {
        return this.http.post<boolean>(this.url + '/addEnfant/'+numAssMalParent, t);
    }

    findAll(): Observable<T[]> {
        return this.http.get<T[]>(this.url);
    }

    findById(id: ID): Observable<T> {
        return this.http.get<T>(this.url + '/' + id);
    }

    checkCitizenValidity(numAssMal: string): Observable<boolean> {
        return this.http.get<boolean>(this.url + '/' + numAssMal);
    }

    login(email: string, password: string): Observable<T>{
        return this.http.get<T>(this.url + '/login/' + email + '/' + password)
    }

    loginExist(email: String): Observable<boolean>{
        return this.http.get<boolean>(this.url + '/' + email)
    }

    requestPermis(t: T): Observable<boolean> {
        return this.http.post<boolean>(this.url + '/requestPermis', t);
    }


    sendEmail(t: T): Observable<boolean> {
        return this.http.post<boolean>(this.url + '/sendEmail', t);
    }

    updateCitoyen(t:T): Observable<T> {
        return this.http.put<T>(this.url + "/update", t);
    }

    update(id: ID, t: T): Observable<T> {
       return this.http.put<T>(this.url + "/" + id, t, {});
    }

    deleteById(id: ID): Observable<T> {
        return this.http.delete<T>(this.url + "/" + id);
    }
    

}