import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { CitoyenSante } from '../models/citoyenSante';
import { GenericService } from './genericService';

@Injectable({
  providedIn: 'root'
})
export class PermisService extends GenericService<CitoyenSante, Number>{

  constructor(http: HttpClient) {
    super(http, "http://localhost:9191/permisSante")
   }

   public userAuthentified(){
     let email = sessionStorage.getItem('email');
     return email != null;
   }

   public logout(){
     sessionStorage.clear();
   }
}
