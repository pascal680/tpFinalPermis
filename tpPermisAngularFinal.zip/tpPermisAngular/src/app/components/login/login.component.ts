import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import {CitoyenSante} from '../../models/citoyenSante'
import {PermisService} from './../../services/permis.service'

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  validMessage: string = "";
  citoyen: CitoyenSante;

  constructor(private service: PermisService, private router: Router) { }

  ngOnInit(): void {
  }

  loginForm = new FormGroup({
    email: new FormControl('', Validators.required),
    password: new FormControl('', Validators.required)
  });

  public login(){
    this.service.login(this.loginForm.get("email").value, this.loginForm.get("password").value).subscribe(
      (data) => {
        if(data != null){
          this.citoyen = data;
          sessionStorage.setItem("email", this.loginForm.get("email").value);
          this.loginForm.reset();
          this.router.navigateByUrl("/dashboard", {state: this.citoyen});
        }else{
          this.validMessage = "Login or password incorrect";
        }
      }
    );
  }

  public sendToSubscribe(){
    this.router.navigateByUrl("/subscribe");
  }

}
