import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { CitoyenService } from 'src/app/services/citoyen.service';
import { PermisService } from 'src/app/services/permis.service';

@Component({
  selector: 'app-subscribe',
  templateUrl: './subscribe.component.html',
  styleUrls: ['./subscribe.component.css']
})
export class SubscribeComponent implements OnInit {

  isValid: boolean = false;
  numAssMal: String = "";
  validityMessage: string = '';
  validMessage: string = '';

  validityForm = new FormGroup({
    numAssMal: new FormControl('', Validators.required)
  });


  subscribeForm = new FormGroup({
    numAssMal: new FormControl('', Validators.required),
    prenom: new FormControl('', Validators.required),
    nom: new FormControl('', Validators.required),
    email: new FormControl('', Validators.required),
    password: new FormControl('', Validators.required),
    sexe: new FormControl('', Validators.required),
    age: new FormControl('', Validators.required),
    numTelephone: new FormControl('', Validators.required),
    villeResidence: new FormControl('', Validators.required)
  });

  constructor(private service: PermisService, private serviceMinistere: CitoyenService, private router: Router) { }

  ngOnInit(): void {
  }


  public onSubscribe(){
    if(this.subscribeForm.valid){
      this.service.save(this.subscribeForm.value).subscribe(
        (data) => {
          if(data != null){
            console.log("ok");
            console.log(this.subscribeForm.value);
            this.subscribeForm.reset();
            this.router.navigateByUrl('/login');
          }else {
            this.validMessage = "Cannot subscribe";
            console.log(this.subscribeForm.value);
          }
        }
      )
    }else{
      this.validMessage = "Please fill out all the fields to register";
    }
  }


  public onCheckValidity(){
    if(this.validityForm.valid){
      this.serviceMinistere.checkCitizenValidity(this.validityForm.get("numAssMal").value).subscribe(
        (data) => {
          if(data){
            this.isValid = true;
            this.numAssMal = this.validityForm.get("numAssMal").value;
          }else{
            this.isValid = false;
            this.validityMessage = "Numero Assurance Maladie not valid!";
          }
        }
      );
    }else{
      this.validityMessage = "Please enter a medicare number to validate";
    }
  }
}
