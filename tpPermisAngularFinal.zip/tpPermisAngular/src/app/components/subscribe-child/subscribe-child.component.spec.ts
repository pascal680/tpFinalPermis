import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SubscribeChildComponent } from './subscribe-child.component';

describe('SubscribeChildComponent', () => {
  let component: SubscribeChildComponent;
  let fixture: ComponentFixture<SubscribeChildComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SubscribeChildComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SubscribeChildComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
