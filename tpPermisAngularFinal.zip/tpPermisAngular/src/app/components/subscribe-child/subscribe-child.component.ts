import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { CitoyenSante } from 'src/app/models/citoyenSante';
import { CitoyenService } from 'src/app/services/citoyen.service';
import { PermisService } from 'src/app/services/permis.service';

@Component({
  selector: 'app-subscribe-child',
  templateUrl: './subscribe-child.component.html',
  styleUrls: ['./subscribe-child.component.css']
})
export class SubscribeChildComponent implements OnInit {


  isValid: boolean = false;
  numAssMal: String = "";
  validityMessage: string = '';
  validMessage: string = '';

  validityForm = new FormGroup({
    numAssMal: new FormControl('', Validators.required)
  });


  subscribeChildForm = new FormGroup({
    numAssMal: new FormControl('', Validators.required),
    prenom: new FormControl('', Validators.required),
    nom: new FormControl('', Validators.required),
    email: new FormControl('', Validators.required),
    password: new FormControl('', Validators.required),
    sexe: new FormControl('', Validators.required),
    age: new FormControl('', Validators.required),
    numTelephone: new FormControl('', Validators.required),
    villeResidence: new FormControl('', Validators.required)
  });


  parent : CitoyenSante;
  constructor(private service: PermisService, private serviceMinistere: CitoyenService, private router: Router) { }

  ngOnInit(): void {
    this.parent = history.state;
  }


  public onSubscribeChild(){
    if(this.subscribeChildForm.valid){
      this.service.saveEnfant(this.parent.numAssMal,this.subscribeChildForm.value).subscribe(
        (data) => {
          if(data){
            console.log("ok");
            console.log(this.subscribeChildForm.value);
            this.subscribeChildForm.reset();
            this.router.navigateByUrl('/dashboard', {state : this.parent});
          }else {
            this.validMessage = "Cannot subscribe child";
            console.log(this.subscribeChildForm.value);
          }
        }
      )
    }else{
      this.validMessage = "Please fill out all the fields to register";
    }
  }


  public onCheckValidity(){
    if(this.validityForm.valid){
      this.serviceMinistere.checkCitizenValidity(this.validityForm.get("numAssMal").value).subscribe(
        (data) => {
          if(data){
            this.isValid = true;
            this.numAssMal = this.validityForm.get("numAssMal").value;
          }else{
            this.isValid = false;
            this.validityMessage = "Numero Assurance Maladie not valid!";
          }
        }
      );
    }else{
      this.validityMessage = "Please enter a medicare number to validate";
    }
  }
}
