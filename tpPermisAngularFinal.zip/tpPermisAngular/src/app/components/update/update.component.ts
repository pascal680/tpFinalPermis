import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CitoyenSante } from 'src/app/models/citoyenSante';
import { PermisService } from 'src/app/services/permis.service';

@Component({
  selector: 'app-update',
  templateUrl: './update.component.html',
  styleUrls: ['./update.component.css']
})
export class UpdateComponent implements OnInit {

  citoyen: CitoyenSante;
  validityMessage: string = "";
  constructor(private router: Router, private service: PermisService) { }

  ngOnInit(): void {
    this.citoyen = history.state;
    console.log(this.citoyen);
  }

  public onUpdate(){
      this.service.save(this.citoyen).subscribe(
        (data) => {
          if(data != null){
            console.log("ok");
            
            this.router.navigateByUrl('/dashboard', {state: (this.citoyen)});
          }else {
            this.validityMessage = "Not able to update info!";
            console.log("not ok");
          }
        }
      )
  }

}
