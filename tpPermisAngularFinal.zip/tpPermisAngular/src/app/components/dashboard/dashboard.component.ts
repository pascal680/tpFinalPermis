import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CitoyenSante } from 'src/app/models/citoyenSante';
import { Permis } from 'src/app/models/permis';
import { PermisService } from 'src/app/services/permis.service';


@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  citoyen: CitoyenSante;
  permis: Permis;
  toggleShowChilds: boolean;
  childs: Array<CitoyenSante>;

  constructor(private router: Router, private service: PermisService ) { }

  ngOnInit(): void {
    this.citoyen = history.state;
    this.refreshCitoyen();
    this.toggleShowChilds = false;
  }

  public sendToUpdate(){
    this.router.navigateByUrl("/update", {state: this.citoyen})
  }

  public requestPermit(){
      this.service.requestPermis(this.citoyen).subscribe(
        (data) =>{
        if(data){
          this.refreshCitoyen();
          // console.log(this.citoyen);
          // console.log(this.permis);
        } else {
          alert("Was unable to request permit");
          console.log("request not working");
        }
        }
      );
  }

  public refreshCitoyen(){
    this.service.login(this.citoyen.email, this.citoyen.password).subscribe(
      (data)=>{
        if(data != null){
          this.citoyen = data;
          this.permis = this.citoyen.permis;
          // console.log(data)
        } else {
          alert("Was unable to refresh profile");
          console.log("Refresh not work");
        }
      }
    );
  }

  public sendEmail(){
    this.service.sendEmail(this.citoyen).subscribe(
      (data) =>{
        if(data){
          alert("Email was sent to email: " + this.citoyen.email);
        }else{
          alert("Was unable to send email to: " + this.citoyen.email);
        }
      }
    );
  }

  public showChilds(){
    this.childs = this.citoyen.enfants;
    if(this.toggleShowChilds){
      this.toggleShowChilds = false;
    }else{
      this.toggleShowChilds = true;
    }
  }

  public sendToSubscribeChild(){
    this.router.navigateByUrl("/subscribeChild", {state: this.citoyen})
  }

  public logout(){
    this.service.logout;
    this.router.navigateByUrl("/login");
  }

}
