import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { Error404Component } from './components/error404/error404.component';
import { LoginComponent } from './components/login/login.component';
import { LogoutComponent } from './components/logout/logout.component';
import { SubscribeChildComponent } from './components/subscribe-child/subscribe-child.component';
import { SubscribeComponent } from './components/subscribe/subscribe.component';
import { UpdateComponent } from './components/update/update.component';
import { AuthGuard} from './services/auth.guard'


const routes: Routes = [
  {path:'dashboard', component:DashboardComponent, canActivate:[AuthGuard]},
  {path:'logout', component:LogoutComponent, canActivate:[AuthGuard]},
  
  {path:'subscribe', component:SubscribeComponent},
  {path:'subscribeChild', component:SubscribeChildComponent},
  {path:'home', redirectTo: '/login', pathMatch: 'full'},
  {path:'login', component:LoginComponent},
  {path:'update', component:UpdateComponent},
  {path:'', redirectTo: '/login', pathMatch: 'full'},
  {path:'**', component:Error404Component}
];

@NgModule({
  imports: [RouterModule.forRoot(routes, { relativeLinkResolution: 'legacy' })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
