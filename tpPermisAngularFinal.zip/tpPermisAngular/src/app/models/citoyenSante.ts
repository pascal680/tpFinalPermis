import { Permis } from "./permis";

export class CitoyenSante{
    id: number;
    nom: string;
    prenom: string;
    password: string;
    email: string;
    numAssMal: string;
    sexe: string //char in java
    age: number;
    numTelephone: string;
    villeResidence: string;
    permis: Permis;
    enfants: Array<CitoyenSante>;
}