export class Permis{
    idPermis: number;
    typePermis: string;
    datePermis: string;
    dateExpirationPermis: string;
}