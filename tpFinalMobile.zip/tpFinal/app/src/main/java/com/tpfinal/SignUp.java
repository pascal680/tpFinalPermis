package com.tpfinal;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.UserHandle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.tpfinal.model.Citoyen;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class SignUp extends AppCompatActivity {

    EditText editTextEmail, editTextPassword, editTextNumAssMal, editTextPrenom, editTextNom, editTextNumTelephone, editTextVilleResidence;
    Spinner spinnerSexe, spinnerAge;

    Citoyen citoyen;

    Character[] sexes = {'M', 'F', 'X'};

    List<Integer> ages = new ArrayList<>();

    boolean isFilledOut;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);


        citoyen = new Citoyen();

        initializeAgeArray(120);


        spinnerAge = findViewById(R.id.spinnerAge);
        spinnerSexe = findViewById(R.id.spinnerSexe);

        editTextEmail = findViewById(R.id.editTextEmail);
        editTextPassword = findViewById(R.id.editTextPassword);
        editTextNumAssMal = findViewById(R.id.editTextNumAssMal);
        editTextPrenom = findViewById(R.id.editTextPrenom);
        editTextNom = findViewById(R.id.editTextNom);
        editTextNumTelephone = findViewById(R.id.editTextNumTelephone);
        editTextVilleResidence = findViewById(R.id.editTextVilleResidence);

        editTextNumAssMal.setText(getIntent().getStringExtra("numAssMal").toUpperCase());


        prepareSpinnerSexe();

        prepareSpinnerAge();

    }

    private void prepareSpinnerAge() {
        ArrayAdapter<Integer> adapterAges = new ArrayAdapter<Integer>(this,
                android.R.layout.simple_spinner_item, ages);

        spinnerAge.setAdapter(adapterAges);

        spinnerAge.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                citoyen.setAge(position +1);
                isFilledOut = true;
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                Toast.makeText(SignUp.this, "Must select age", Toast.LENGTH_SHORT).show();
                isFilledOut = false;
            }
        });
    }

    private void prepareSpinnerSexe() {
        ArrayAdapter<Character> adapterSexe = new ArrayAdapter<Character>(this,
                android.R.layout.simple_spinner_item, sexes);

        spinnerSexe.setAdapter(adapterSexe);

        spinnerSexe.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                citoyen.setSexe(sexes[position]);
                isFilledOut = true;
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                Toast.makeText(SignUp.this, "Must select age", Toast.LENGTH_SHORT).show();
                isFilledOut = false;
            }
        });
    }

    public void signUp(View view){
        checkFilledOut();
        if(isFilledOut) {
            citoyen.setPrenom(editTextPrenom.getText().toString());
            citoyen.setNom(editTextNom.getText().toString());
            citoyen.setEmail(editTextEmail.getText().toString());
            citoyen.setPassword(editTextPassword.getText().toString());
            citoyen.setNumTelephone(editTextNumTelephone.getText().toString());
            citoyen.setVilleResidence(editTextVilleResidence.getText().toString());
            citoyen.setNumAssMal(editTextNumAssMal.getText().toString());
            Log.i("citoyen", citoyen.toString());
            sendPost(citoyen);
        }else{
            Toast.makeText(SignUp.this, "Must fill out registration fully", Toast.LENGTH_SHORT).show();
        }
    }

    private void sendPost(Citoyen citoyen){
        //Create retrofit instance
        Retrofit.Builder builder = new Retrofit.Builder()
                .baseUrl("http://10.0.2.2:9191/permisSante/")
                .addConverterFactory(GsonConverterFactory.create());

        Retrofit retrofit = builder.build();

        CitoyenClient client = retrofit.create(CitoyenClient.class);
        Call<Citoyen> call = client.createCitoyen(citoyen);
        
        call.enqueue(new Callback<Citoyen>() {
            @Override
            public void onResponse(Call<Citoyen> call, Response<Citoyen> response) {
                Toast.makeText(SignUp.this, "Sign Up successful for account with login: " + response.body().getEmail(), Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(SignUp.this, MainActivity.class);
                startActivity(intent);
            }

            @Override
            public void onFailure(Call<Citoyen> call, Throwable t) {
                Toast.makeText(SignUp.this, "Unable to Sign Up", Toast.LENGTH_SHORT).show();
            }
        });
    }


    private void initializeAgeArray(int maxAge){
        for(int i = 1; i<= maxAge; i++){
            ages.add(i);
        }
    }

    private void checkFilledOut(){
        if(editTextPrenom.getText().toString() != "" && isFilledOut == false){
            isFilledOut = true;
        }

        if(editTextNom.getText().toString() != "" && isFilledOut == false){
            isFilledOut = true;
        }

        if(editTextEmail.getText().toString() != "" && isFilledOut == false){
            isFilledOut = true;
        }

        if(editTextPassword.getText().toString() != "" && isFilledOut == false){
            isFilledOut = true;
        }

        if(editTextNumTelephone.getText().toString() != "" && isFilledOut == false){
            isFilledOut = true;
        }

        if(editTextVilleResidence.getText().toString() != "" && isFilledOut == false){
            isFilledOut = true;
        }
    }

}