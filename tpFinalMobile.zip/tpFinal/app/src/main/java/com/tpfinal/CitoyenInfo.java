package com.tpfinal;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;
import com.tpfinal.model.Citoyen;
import com.tpfinal.model.Permis;

public class CitoyenInfo extends AppCompatActivity {

    TextView textViewNom, textViewEmail, textViewNumTelephone, textViewVilleResidence, textViewAge, textViewSexe, textViewNumAssMal, textViewMessagePermis;
    ImageView qrCodeImageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_citoyen_info);

        Intent i = getIntent();
        Citoyen citoyen = (Citoyen) i.getSerializableExtra("citoyen");
        Permis permis = (Permis) i.getSerializableExtra("permis") ;

        textViewNom = findViewById(R.id.textViewNom);
        textViewEmail = findViewById(R.id.textViewEmail);
        textViewNumTelephone = findViewById(R.id.textViewNumTelephone);
        textViewVilleResidence = findViewById(R.id.textViewVilleResidence);
        textViewAge = findViewById(R.id.textViewAge);
        textViewSexe = findViewById(R.id.textViewSexe);
        textViewNumAssMal = findViewById(R.id.textViewNumAssMal);
        textViewMessagePermis = findViewById(R.id.textViewMessagePermis);

        qrCodeImageView = findViewById(R.id.qrCodeImageView);



        initializeInfoCitoyen(citoyen);


        initializePermis(citoyen, permis);


    }

    private void initializePermis(Citoyen citoyen, Permis permis) {
        if(permis != null){
            Picasso.with(this)
                    .load("http://10.0.2.2:9191/permisSante/qrcode/" + citoyen.getNumAssMal())
                    .fit()
                    .centerCrop()
                    .into(qrCodeImageView);
        }else{
            qrCodeImageView.setVisibility(View.GONE);
            textViewMessagePermis.setVisibility(View.VISIBLE);
        }
    }

    private void initializeInfoCitoyen(Citoyen citoyen) {
        textViewNom.setText(textViewNom.getText() + citoyen.getPrenom() + " " + citoyen.getNom());
        textViewEmail.setText(textViewEmail.getText()+ citoyen.getEmail());
        textViewNumTelephone.setText(textViewNumTelephone.getText()+ citoyen.getNumTelephone());
        textViewVilleResidence.setText(textViewVilleResidence.getText() + citoyen.getVilleResidence());
        textViewAge.setText(textViewAge.getText() + Integer.toString(citoyen.getAge()));
        textViewSexe.setText(textViewSexe.getText() + Character.toString(citoyen.getSexe()));
        textViewNumAssMal.setText(textViewNumAssMal.getText() + citoyen.getNumAssMal());
    }
}